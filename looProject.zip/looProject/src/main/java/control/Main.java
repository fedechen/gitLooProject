package control;

import dao.EmployeeDao;
import model.Employee;
import view.FrameBase;

public class Main {

	
	public static void main(String[] args) {
//		Employee e = new Employee();
//		e.setName("Emerson Fedechen");
//		
//		EmployeeDao dao = new EmployeeDao();
//		dao.save(e);
		
		new FrameBase();
		
		
	}
}
