package view;

import java.awt.FlowLayout;

import javax.swing.JPanel;

public class Menus extends JPanel implements VisualComponent{

	
	public Menus() {
		setLayouts();
		setComponents();
		setEvents();
	}
	
	
	
	public void setLayouts() {
		setLayout(new FlowLayout());
		
	}

	public void setComponents() {
		// TODO Auto-generated method stub
		
	}

	public void setEvents() {
		// TODO Auto-generated method stub
		
	}

}
