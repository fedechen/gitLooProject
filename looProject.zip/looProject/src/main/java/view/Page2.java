package view;

import java.awt.Color;

import javax.swing.JPanel;

public class Page2 extends JPanel implements VisualComponent{

	public Page2() {
		setLayouts();
		setComponents();
		setEvents();
	}
	
	
	public void setLayouts() {
		setLayout(null);
		setBackground(Color.BLUE);
		setSize(800, 600);
		setVisible(true);
		
	}

	public void setComponents() {
		// TODO Auto-generated method stub
		
	}

	public void setEvents() {
		// TODO Auto-generated method stub
		
	}

}
