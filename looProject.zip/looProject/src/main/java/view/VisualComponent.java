package view;

public interface VisualComponent {

	public void setLayouts();
	public void setComponents();
	public void setEvents();
	
	
}
